// Registrejam pogas etc
const button1 = document.getElementById("b1");
const square1 = document.getElementById("square1");

const button2 = document.getElementById("b2");
const square2 = document.getElementById("square2");

const button3 = document.getElementById("b3");
const square3 = document.getElementById("square3");

const button4 = document.getElementById("b4");
const square4 = document.getElementById("square4");

const button5 = document.getElementById("b5");
const square5 = document.getElementById("square5");

const button6 = document.getElementById("b6");
const square6 = document.getElementById("square6");

const button7 = document.getElementById("b7");
const square7 = document.getElementById("square7");

const inputField = document.getElementById('input-field');
const textDisplay = document.createElement('div');

//event uz click pirma kvadrata krasa mainas uz dzeltena
button1.addEventListener("click", function() {
    square1.style.backgroundColor = "yellow";
});
//event uz click otra kvadrata teksta kontents mainas uz success
button2.addEventListener("click", function() {
    square2.textContent = "SUCCESS";
});
//hide square
button3.addEventListener("click", function() {
    square3.style.opacity = 0;
});
//hide un onhide
button4.addEventListener("click", function() {
    square4.style.opacity = square4.style.opacity === "0" ? "1" : "0";
});
//izveidojam krasu masivu kurs uz event click kad uzspiedis pogu ies pa rinki
button5.addEventListener("click", function() {
    const colors = ["red", "blue", "green", "orange", "purple"];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    square5.style.backgroundColor = randomColor;
})
//timeris uz event
function timer1() {
    var currentValue = parseInt(document.getElementById("square6").innerHTML);
    if (currentValue < 10) {
        setTimeout(function() {
            document.getElementById("square6").innerHTML = currentValue + 1;
            timer1();
        }, 3000);
    }
}

document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("b6").addEventListener("click", function() {
        timer1();
    });
});
//mainam visas krasas
button7.addEventListener("click", function(){
    square1.style.backgroundColor = "#18D5E1";
    square2.style.backgroundColor = "#18D5E1";
    square3.style.backgroundColor = "#18D5E1";
    square4.style.backgroundColor = "#18D5E1";
    square5.style.backgroundColor = "#18D5E1";
    square6.style.backgroundColor = "#18D5E1";
    document.body.style.backgroundColor = "#000000";
    textDisplay.style.color = "cyan";
})

//ja pele uziet uz square krasa mainas
square1.addEventListener("mouseover", function(){
    square1.style.backgroundColor = "red";

})
//timeris kad uziet uz square un bedzas kad noiet no square
let count = 0;
let intervalId;

function startTimer() {
    intervalId = setInterval(() => {
        square5.textContent = count++;
        if (count > 10) {
            stopTimer();
        }
    }, 1000);
}

function stopTimer() {
    clearInterval(intervalId);
    count = 0;
    square5.textContent = count;
}
//event kas izauc
square5.addEventListener('mouseenter', startTimer);
square5.addEventListener('mouseleave', stopTimer);

//kad raksta paradas live

inputField.insertAdjacentElement('afterend', textDisplay);

function updateTextDisplay() {

    textDisplay.textContent = inputField.value;
}

inputField.addEventListener('input', updateTextDisplay);