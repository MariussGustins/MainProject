//izveidojam data objektu kurs ievac datus no localstortage un konverto uz js, ja myobject bus tukš tad izvadis šis default vertibas
const data = JSON.parse(localStorage.getItem('allData')) || {
    name: '',
    surname: '',
    style: '',
    meters: '',
    entry: ''
};
// Ja localstorage satur allData, tad tiek atjaunots HTML, izmantojot foreach ciklu, kas pārskata katru data elementu un pievieno to rindai.
function disData() {
    if (localStorage.getItem('allData')) {
        const output = document.querySelector('tbody');
        output.innerHTML = "";
        const dataArray = JSON.parse(localStorage.getItem('allData'));
        //partaisam sunu par contenteditable, kas ļaus rediģet šunas, onblur kad tiks izkliskinats ara dati saglabasies, talak displayos sunas datus izmantojot data.nameValue, kas tiek ieguts no localstorage.data.id tiek izmantots ka unikals identifikatrs lai atskirtu katru tabulas rindu
        dataArray.forEach(data => {
            output.innerHTML += `
        <tr>
          <td contenteditable="true" onblur="updateData(this, 'nameValue', ${data.id})">${data.nameValue}</td>
          <td contenteditable="true" onblur="updateData(this, 'surnameValue', ${data.id})">${data.surnameValue}</td>
          <td contenteditable="true" onblur="updateData(this, 'styleValue', ${data.id})">${data.styleValue}</td>
          <td contenteditable="true" onblur="updateData(this, 'metersValue', ${data.id})">${data.metersValue}</td>
          <td contenteditable="true" onblur="updateData(this, 'entryValue', ${data.id})">${data.entryValue}</td>
          <td><button class="delete-button" onclick="deleteRow(${data.id})">Delete</button></td>
        </tr>
      `;
        });
    }
}
// Atjaunina localStorage un saglabā izmaiņas pēc tam, ir rediģēti dati
function updateData(element, key, id) {
    const dataArray = JSON.parse(localStorage.getItem('allData'));
    const dataObj = dataArray.find(data => data.id === id);
    dataObj[key] = element.innerText;
    localStorage.setItem('allData', JSON.stringify(dataArray));
}
// Dzēš rindu no localStorage un atjauno HTML.
function deleteRow(id) {
    let dataArray = JSON.parse(localStorage.getItem('allData'));
    const index = dataArray.findIndex(data => data.id === id);
    if (index > -1) {
        dataArray.splice(index, 1);
        localStorage.setItem('allData', JSON.stringify(dataArray));
        disData();
    }
}
// Attēlo sākotnējos datus HTML lapā.
disData();
//funkcija, kas exportes datus uz csv failu
function exportData() {
    // Iegūstam datus no localStorage un pārvēršam to atpakaļ par objektiem
    const data = JSON.parse(localStorage.getItem('allData'));
    // Definējam virsrakstu atslēgas manuāli, jo nav vairs "allData" masīva ar virsrakstu atslēgām
    const headers = ['nameValue', 'surnameValue', 'styleValue', 'metersValue', 'entryValue'];
    // Izveidojam lapu ar datiem, izmantojot virsrakstu atslēgas un datus
    const worksheet = XLSX.utils.json_to_sheet(data, {header: headers});
    // Izveidojam excel un pievienojam tajā mūsu lapu ar datiem
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Data');
    // Lejupielādējam excel kā CSV failu
    XLSX.writeFile(workbook, 'tableData.csv');
}

document.querySelector('#downloadBtn').addEventListener('click', exportData);


