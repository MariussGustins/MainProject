//selectojam form un parejos datus
const form = document.getElementById('form');
const name = document.getElementById('name');
const surname = document.getElementById('surname');
const style = document.getElementById('style');
const meters = document.getElementById('meters');
const entry = document.getElementById('entry');

//izveidojam event listener uz formas , un saglabājas datus localstorage

form.addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = {
        nameValue: name.value,
        surnameValue:surname.value,
        styleValue: style.value,
        metersValue:meters.value,
        entryValue: entry.value
    }

    const storedData = JSON.parse(localStorage.getItem('allData')) || [];

    storedData.push(formData);

    localStorage.setItem('allData', JSON.stringify(storedData));

    window.location.href = "display.html";

});

