let reviews = [];
function submitReview(event) {
    event.preventDefault();
    const carModel = document.getElementById("car-model").value;
    const rating = document.getElementById("rating").value;
    const review = document.getElementById("review").value;
    const newReview = { carModel, rating, review };
    reviews.push(newReview);
    localStorage.setItem("reviews", JSON.stringify(reviews));
    document.getElementById("review-form").reset();
}
function showReviews() {
    const savedReviews = JSON.parse(localStorage.getItem("reviews")) || [];
    const tbody = document.getElementById("review-table").getElementsByTagName("tbody")[0];

    // clear any existing reviews from the table
    tbody.innerHTML = "";

    // loop through the saved reviews and add them to the table as new rows
    savedReviews.forEach((review) => {
        const row = tbody.insertRow();
        const carModelCell = row.insertCell(0);
        const ratingCell = row.insertCell(1);
        const reviewCell = row.insertCell(2);

        carModelCell.innerHTML = review.carModel;
        ratingCell.innerHTML = review.rating;
        reviewCell.innerHTML = review.review;
    });
}
function changeHeaderColor() {
    var headers = document.getElementsByTagName('th');
    for (var i = 0; i < headers.length; i++) {
        headers[i].style.backgroundColor = 'green';
    }
}


function shuffleRankings() {
    var tbody = document.querySelector("table tbody");
    for (var i = tbody.children.length; i >= 0; i--) {
        tbody.appendChild(tbody.children[Math.random() * i | 0]);
    }
}


