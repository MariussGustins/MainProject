// masivs ar info
const cardData = [
    {
        title: "Python",
        description: "This is the most popular language.",
        skills: "Basic front-end knowledge can ease the learning process.",
        image: "pyt.png"
    },
    {
        title: "C#",
        description: "This is the second most popular language.",
        skills: "Basic knowledge of C and object-oriented programming language approach can smooth the learning process.",
        image: "csharp.png"
    },
    {
        title: "C++",
        description: "This is the third most popular language.",
        skills: "Problem-solving, computer functions, and basic programming knowledge.",
        image: "cplus.png"
    }
];

// funkcija, kas izvadis ara info uz kartim
function izvadit(card) {
    return `
    <div class="card">
      <img src="${card.image}" alt="${card.title}">
      <h2>${card.title}</h2>
      <p>${card.description}</p>
      <button class="more-info-btn">Skill Requirements</button>
      <div class="dropdown">
        <p>${card.skills}</p>
    </div>
    </div>
  `;
}

// funkcija kas ievietos kartis html
const cardContainer = document.getElementById("card-container");
cardData.forEach(card => {
    const cardHTML = izvadit(card);
    cardContainer.innerHTML += cardHTML;
});

// extra, kad uzpiedies pogu more info jeb skill tad paradisies dorpdown ar atrtiecigo info
const moreInfoButtons = document.querySelectorAll(".more-info-btn");
moreInfoButtons.forEach(button => {
    button.addEventListener("click", () => {
        const card = button.closest(".card");
        card.classList.toggle("show");
    });
});
//mainis karsu teksta izmeru h2
function changeTitleSize(size) {
    const titles = document.querySelectorAll('.card h2');
    titles.forEach(title => {
        title.style.fontSize = `${size}px`;
    });
}
//mainis krasu background
function changeCardColor(color) {
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.style.backgroundColor = color;
    });
}
//mainis border biezumu
function changeCardBorderWidth(width) {
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.style.borderWidth = `${width}px`;
    });
}
//nonems bildes un pievinos
function toggleCardImages() {
    const images = document.querySelectorAll('.card img');
    images.forEach(image => {
        image.style.display = image.style.display === 'none' ? 'block' : 'none';
    });
}

